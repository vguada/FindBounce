(* ::Package:: *)

Get["FindBounce"];
